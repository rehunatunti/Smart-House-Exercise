﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlytaloWPF
{
    public class Thermostat
    {
        public double Temperature { get; set; }


    }
}
