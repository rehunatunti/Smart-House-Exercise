﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlytaloWPF
{
    public class Lights
    {
        // ominaisuudet
        public bool Switched { get; set; } // tämä itsessään on jo työkalu ja metodit, millä voidaan asettaa arvot
        public int Dimmer { get; set; } // Huom, tehtävänannossa alunperin string textboxin takia

        
    }
}
