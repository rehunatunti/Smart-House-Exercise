﻿namespace AlytaloWPF
{
    internal class SideWindow
    {
    }
}